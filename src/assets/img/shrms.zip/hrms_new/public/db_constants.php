<?php
	           defined('HRMS_HOST') || define('HRMS_HOST','localhost');
	           defined('HRMS_USERNAME') || define('HRMS_USERNAME','root');
	           defined('HRMS_PASSWORD') || define('HRMS_PASSWORD','');
	           defined('HRMS_DBNAME') || define('HRMS_DBNAME','sentrifugo_db');
	           
	         ?>
