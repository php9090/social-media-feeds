<?php
       defined('SUPERADMIN_EMAIL') || define('SUPERADMIN_EMAIL','dev.net.asp@gmail.com');
       defined('APPLICATION_NAME') || define('APPLICATION_NAME','HRMS');
     ?>