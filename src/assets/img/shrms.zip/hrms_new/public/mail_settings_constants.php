<?php
	           defined('MAIL_SMTP') || define('MAIL_SMTP','smtp.gmail.com');
	           defined('MAIL_USERNAME') || define('MAIL_USERNAME','dev.net.asp@gmail.com');
	           defined('MAIL_PASSWORD') || define('MAIL_PASSWORD','Wel@come123');
	           defined('MAIL_PORT') || define('MAIL_PORT','25');
	           defined('MAIL_AUTH') || define('MAIL_AUTH','true');
	           defined('MAIL_TLS') || define('MAIL_TLS','');
	         ?>